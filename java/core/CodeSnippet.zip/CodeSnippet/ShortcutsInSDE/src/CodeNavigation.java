public class CodeNavigation {

	public static void main(String args[]) {
		UnformattedCode.add(10, 20);
	}
}
