
public class UnformattedCode {
public static int sum =0;
public static void main(String args[]){
System.out.println("This is an example of unformatted code in java");
add(5,4);
}

public static void add(int x,int y){
sum=x+y;
System.out.println("This can" +
		" print the sum of " +
"two numbers. The sum is "+sum);
}
}
