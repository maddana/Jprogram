import java.lang.Integer;

public class OrganizeImports {

	public static void main(String args[]) {

		Calendar cal = Calendar.getInstance();
		System.out.println(cal.getTime());
	}
}
