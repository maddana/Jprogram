package string_24;

public class StringApp {
	
	public static void main(String arg[]){
		String string ="Welcome to Java World";
		System.out.print("\n"+string.charAt(5));
		System.out.print("\n"+string.compareTo("Welcome"));
		string+="-Let us learn";
		System.out.print("\n"+string.indexOf('a'));
		string.replace('a', 'e');
		System.out.print("\n"+string.substring(4, 10));
		System.out.print("\n"+string.toLowerCase());
	}
}
