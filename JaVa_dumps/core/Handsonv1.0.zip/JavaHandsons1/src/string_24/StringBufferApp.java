package string_24;

public class StringBufferApp {
	public static void main(String arg[]){
		StringBuffer strbuff = new StringBuffer("This is StringBuffer");
		strbuff.append("-This is a sample program");
		strbuff.insert(21,"Object");
		System.out.print("\n"+strbuff.reverse());
		strbuff.reverse();
		strbuff.replace(strbuff.indexOf("Buffer"), strbuff.indexOf("Buffer")+6, "Builder");
		System.out.print("\n"+strbuff);
	}
}
