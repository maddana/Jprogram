package string_24;

import java.util.StringTokenizer;

public class StringParserApp {
	public static void main(String arg[]){
		String string = new String("C:\\IBM\\DB2\\PROGRAM\\DB2COPY1.EXE");
		//System.out.print("\n"+string);
		
		StringTokenizer st = new StringTokenizer(string, "\\");
		String drive="";
		String folder="";
		String file="";
		
		drive = st.nextToken();
		drive+="\\";
		while(st.hasMoreTokens()){
			String temp;
			temp =st.nextToken();
			if(st.hasMoreTokens())
				{
				folder+=temp;
				folder+="\\";
				}
			else
				file=temp;
			
		}
		
		System.out.print("\nDrive: "+drive);
		System.out.print("\nFolder: "+folder);
		System.out.print("\nfile: "+file);
	}
}
