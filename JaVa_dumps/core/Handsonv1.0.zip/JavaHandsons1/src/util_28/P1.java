package util_28;

import java.text.SimpleDateFormat;
import java.util.Date;

public class P1 {

	
	public static void main(String[] args) {
		Date date = new Date();
		System.out.print("\n"+date);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/M/yy h:mm a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("MMM d,yyyy h:mm:ss a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("h:mm a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("h:mm:ss a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("h:mm:ss a z");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("d/M/yy h:mm a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("MMM d,yyyy h:mm a");
		System.out.print("\n"+formatter.format(date));
		
		formatter.applyPattern("MMM d,yyyy h:mm:ss a z");
		System.out.print("\n"+formatter.format(date));
		
		System.out.print("\n\nThis is not part of handson:");
		formatter.applyPattern("MMM d,yyyy h:mm:ss a");
		System.out.print("\n"+formatter.format(date));

	}

}
