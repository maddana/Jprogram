package util_28;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class P2_P3 {

	

	public static void main(String[] args) {
		
		Calendar calendar = new GregorianCalendar();
		System.out.print("\nnow info: "+calendar.get(Calendar.DATE)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get(Calendar.YEAR));
		
		calendar.add(Calendar.DATE, 10);
		System.out.print("\nAfter Adding info: "+calendar.get(Calendar.DATE)+"/"+calendar.get(Calendar.MONTH)+"/"+calendar.get(Calendar.YEAR));
		
	}

}
