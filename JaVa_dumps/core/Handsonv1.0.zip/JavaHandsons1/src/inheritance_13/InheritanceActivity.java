package inheritance_13;

public class InheritanceActivity {

	public static void main(String[] args) {
		Manager manager= new Manager(12634,"Peter","Chennai India","237844",65000);
		manager.calculateSalary();
		manager.calculateTransportAllowance();
		
		Trainee trainee = new Trainee(29856,"Jack","Mumbai India","442085",45000);
		trainee.calculateSalary();
		trainee.calculateTransportAllowance();
	}

}
