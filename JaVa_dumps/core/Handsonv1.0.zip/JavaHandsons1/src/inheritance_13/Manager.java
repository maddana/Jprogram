package inheritance_13;

public class Manager extends Employee{
	
	Manager(){};
	Manager(int id, String Name,String address, String phone, double salary){
		super(id,Name,address,phone);
		basicSalary = salary;
	}
	
	void calculateTransportAllowance(){
		double transportAllowance;
		transportAllowance = 0.15*basicSalary;
		System.out.print("\n(M)Travel Allowance: "+transportAllowance);
	}
}
