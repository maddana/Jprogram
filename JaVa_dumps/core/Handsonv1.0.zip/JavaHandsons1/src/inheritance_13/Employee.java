package inheritance_13;

public class Employee {
	int employeeId;
	String employeeName;
	String employeeAddress;
	String employeePhone;
	double basicSalary;
	double spcialAllowance = 250.80;
	double Hra = 1000.50;
	
	Employee(){}
	Employee(int Id, String Name, String address, String phone){
		employeeId = Id;
		employeeName = Name;
		employeeAddress = address;
		employeePhone = phone;
	}
	
	void calculateSalary(){
		double salary;
		salary = basicSalary + (basicSalary+spcialAllowance/100)+basicSalary*Hra/100;
		System.out.print("\nSalary of the employee is "+salary);
	}	
	void calculateTransportAllowance(){
		double transportAllowance;
		transportAllowance = 0.1*basicSalary;
		System.out.print("\n(B)Travel Allowance: "+transportAllowance);
	}
}

