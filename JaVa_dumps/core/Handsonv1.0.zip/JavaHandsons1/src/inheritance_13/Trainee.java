package inheritance_13;

public class Trainee extends Employee{
	
	Trainee() {}
	Trainee(int id, String Name,String address, String phone, double salary){
		super(id,Name,address,phone);
		basicSalary = salary;
	}
}
