package interface_13;

public class KidUser implements LibraryUser {
	int age;
	String bookType;
	
	@Override
	public void registerAccount(int age) {
		this.age =age;
		if(age<12)
			System.out.print("\nYou have successfully registered under a kids account");
		else
			System.out.print("\nAge must be less than 12 to reg unders kids section");
	}

	@Override
	public void requestBook(String bookType) {
		if(bookType == "Kids")
			System.out.print("\nBook Issued successfully, please return the book within 10 days");
		else
			System.out.print("\nOops, you are allowed to take only kids books");
	}

}
