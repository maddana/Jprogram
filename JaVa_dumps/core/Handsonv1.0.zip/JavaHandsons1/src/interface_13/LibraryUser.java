package interface_13;

public interface LibraryUser {
	void registerAccount(int age);
	void requestBook(String bookType);
}