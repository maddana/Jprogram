package interface_13;

public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		KidUser kiduser = new KidUser();
		kiduser.registerAccount(10);
		kiduser.registerAccount(18);
		kiduser.requestBook("Kids");
		kiduser.requestBook("Fiction");
		
		AdultUser adultuser = new AdultUser();
		adultuser.registerAccount(10);
		adultuser.registerAccount(18);
		adultuser.requestBook("Kids");
		adultuser.requestBook("Fiction");
	}

}

 