package Intro_activity2;

class DisplayMessage{
	  
	  void printMessage(){
	   System.out.print("\n Hello My Message");
	   System.out.print("");
	}
	  
}  