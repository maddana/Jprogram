package Intro_activity2;

	

	class  MyProgram extends DisplayMessage
	  {
	    public static void main(String arg[]){
	      MyProgram program=new MyProgram();
	      program.printMessage();
	   }
	}
