package com.cognizant.tax;

public class EmployeeTax extends TaxCalculator{
	public static void main(String []args){
		TaxCalculator tax =new TaxCalculator();
		
		tax.setBasicSalary(125000);
		tax.setCitizenship(true);
		tax.calculateTax();
		tax.deduceTax();
		tax.validateSalary();
		
	}

}
