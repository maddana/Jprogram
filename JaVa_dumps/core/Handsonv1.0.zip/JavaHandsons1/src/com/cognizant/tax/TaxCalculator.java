package com.cognizant.tax;

public class TaxCalculator {
	float basicSalary;
	public float getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}
	public boolean isCitizenship() {
		return citizenship;
	}
	public void setCitizenship(boolean citizenship) {
		this.citizenship = citizenship;
	}
	boolean citizenship;
	float tax;
	void calculateTax(){
		

	tax =((float)30.0*basicSalary)/100;
	System.out.println("The Tax of the employee  for  the"+basicSalary+ "is" +tax);
	
	}
	void deduceTax(){
		int nettSalary;
		nettSalary=(int)(basicSalary-tax);
		System.out.println(tax+"  "+(basicSalary-tax));
		
		System.out.println("The nett salary of the employee: "+nettSalary);
	}
	
	void validateSalary(){
		if(basicSalary>100000&& citizenship==true)
			System.out.println("The salary and citizenship eligibility:  true");
		else
			System.out.println("The salary and citizenship eligibility:  false");
	}
}
