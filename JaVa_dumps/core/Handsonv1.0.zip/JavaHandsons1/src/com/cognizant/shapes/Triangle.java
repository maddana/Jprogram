package com.cognizant.shapes;

public class Triangle {
	public static final int sides=3;
	double area;
	void calculateArea(){
		area=.433*sides*sides;
		System.out.println("the area is: " +area);
	}
	float calculateArea(int side){
		return 0.433f*side*side;
		}
	
}
