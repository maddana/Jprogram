package com.cognizant.shapes;

public class Circle {
	public static final int sides=1;
	@SuppressWarnings("unused")
	private float radius;
	float pi=3.5f;
	double area;
	@SuppressWarnings("unused")
	private Circle(){
		radius=(float)1.5;
	}
	
	public Circle(float radius){
		this(radius,3.5f);
		
	}
	
	public Circle(float radius, float pi){
		this.pi=pi;
		
	}
	
	float calculateArea(float radius){
		area=pi*radius*radius;
		return (float)area;
		
	}
	
	float calculateCircumference(float radius){
		return 2*pi*radius;
	}

}
