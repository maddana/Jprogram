package com.cognizant.shapes;

public class Shapes {
	
	void calculateShapeArea(int noOfSides, int sideLength){
		switch(noOfSides){
		case 1:
			Circle cob = new Circle(noOfSides);
			System.out.print("\nArea of circle is "+cob.calculateArea(sideLength));
			break;
		case 3:
			Triangle tob =new Triangle();
			System.out.print("\nArea of Triangle is "+tob.calculateArea(sideLength));
			break;
		case 4:
			Square sob = new Square();
			System.out.print("\nArea of Square is "+sob.calculateArea(sideLength));
			break;
		default:
			System.out.print("\nNo Shapes Present");
		}
			
	}
	
	public static void main(String arg[]){
		Shapes shapes  = new Shapes();
		shapes.calculateShapeArea(3, 12);
		shapes.calculateShapeArea(4, 15);
		shapes.calculateShapeArea(5,15);
	}
}
