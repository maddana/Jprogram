package com.cognizant.shapes;

public class AreaCalculator extends Rectangle{
	public static void main(String arg[]){
		Rectangle areacal=new Rectangle();
		areacal.calculateArea();
		
	}

}
