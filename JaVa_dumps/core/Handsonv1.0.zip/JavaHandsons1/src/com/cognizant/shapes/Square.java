package com.cognizant.shapes;

public class Square {
	public static final int sides=4;
	double area;
	
	void calculateArea(){
		area=sides*sides;
		System.out.println("the area is: " +area);
	}
	
	int calculateArea(int side){
		return side*side;
	}
}
