package com.cognizant.geometry;

import com.cognizant.shapes.Circle;

public class Shapes{
	public static void main(String []args){
		float radius=1.2f;
		Circle circle1=new Circle();
		Circle circle2 = new Circle(radius);
	}
	
}
