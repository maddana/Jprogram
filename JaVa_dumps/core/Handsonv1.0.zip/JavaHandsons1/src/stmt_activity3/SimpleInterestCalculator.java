package stmt_activity3;

public class SimpleInterestCalculator {
	double principleAmount;
	int numberOfYears;	
	double simpleInterest;

	double calculateSimpleInterest(int principleAmount,int numberOfYears){
	if(principleAmount > 100000){
		if(numberOfYears > 10)
			simpleInterest = 0.1*principleAmount*numberOfYears;
		else
			simpleInterest = 0.095*principleAmount*numberOfYears;
	}
	
	else{
		if(numberOfYears > 10)
			simpleInterest = 0.05*principleAmount*numberOfYears;
		else
			simpleInterest = 0.045*principleAmount*numberOfYears;
	}
	
	System.out.print("\nThe interest amount for a principal of "+principleAmount + " and years "+ numberOfYears+ " is " +simpleInterest);
	return simpleInterest;
	}
	
	public static void main(String[] arg){
		SimpleInterestCalculator calculator = new SimpleInterestCalculator();
		calculator.calculateSimpleInterest(200000, 12);
		calculator.calculateSimpleInterest(50000, 12);
		calculator.calculateSimpleInterest(50000, 5);
	}

}
