package exceptionHandling_22;

public class TaxNotEligibleException extends Exception {

	private static final long serialVersionUID = 1L;

	public TaxNotEligibleException() {
		super("TaxNotEligible");
	}
}
