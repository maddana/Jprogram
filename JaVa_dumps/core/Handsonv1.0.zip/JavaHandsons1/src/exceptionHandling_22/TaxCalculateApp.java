package exceptionHandling_22;

public class TaxCalculateApp {
	public static void main(String arg[]){
		TaxCalculator tc = new TaxCalculator();
		
		try{
			//tc.calculateTax("Ron", false, 34000);
			//tc.calculateTax("Tim", true, 1000);
			//tc.calculateTax("Jack", true, 55000);
			tc.calculateTax(null, true, 30000);
			
		}
		catch(CountryNotValidException ce){
			System.out.print("\nThe employee should be an Indian citizen for calculating tax");
			ce.printStackTrace();
		}
		catch(EmployeeNameInvalidException ee){
			System.out.print("\nThe employee name cannot be empty\n");
			ee.printStackTrace();
		}
		catch(TaxNotEligibleException te){
			System.out.print("\nThe employee does not need to pay tax");
			te.printStackTrace();
		}
	}
}
