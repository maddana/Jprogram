package exceptionHandling_22;

public class CountryNotValidException extends Exception {
	
	private static final long serialVersionUID = 1L;

public CountryNotValidException() {
	super("CountryNotValid");
}
}
