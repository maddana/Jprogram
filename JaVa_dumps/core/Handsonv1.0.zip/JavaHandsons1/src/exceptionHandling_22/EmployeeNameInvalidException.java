package exceptionHandling_22;

public class EmployeeNameInvalidException extends Exception {
	private static final long serialVersionUID = 1L;

EmployeeNameInvalidException(){
	super("EmployeeNameInvalid");
}
}
