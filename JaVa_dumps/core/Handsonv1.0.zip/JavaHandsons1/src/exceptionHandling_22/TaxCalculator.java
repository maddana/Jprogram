package exceptionHandling_22;

public class TaxCalculator {
	String empName = new String();
	boolean isIndian = true;
	double empSal=0.0;
	double taxAmount;
	
	void calculateTax(String empName,boolean isIndian,double empSal)
	throws CountryNotValidException,EmployeeNameInvalidException,
	TaxNotEligibleException{
		if(!isIndian)
			throw new CountryNotValidException();
		else if(empName == null || empName.isEmpty())
			throw new EmployeeNameInvalidException();
		else{
			if(empSal>100000)
				taxAmount = empSal*0.08;
			else if(empSal>50000)
				taxAmount = empSal*0.06;
			else if(empSal>30000)
				taxAmount = empSal*0.05;
			else if(empSal>10000)
				taxAmount = empSal*0.04;
			else
				throw new TaxNotEligibleException();
			System.out.print("\nTax amount is "+taxAmount);
		}
	}
}
