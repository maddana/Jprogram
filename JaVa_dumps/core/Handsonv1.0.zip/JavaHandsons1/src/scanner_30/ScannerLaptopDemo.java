package scanner_30;

import java.util.Scanner;

public class ScannerLaptopDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int option=0;
		int number1;
		int number2;
		
		do {
			System.out.print("\n1.Addition\n2.Substraction\n3.Multiplication\n4.Quit");
			System.out.print("\nEnter your choice: ");
			option = scanner.nextInt();
			switch(option){
			case 1:
				System.out.print("\nEnter number1: ");
				number1 = scanner.nextInt();
				System.out.print("\nEnter number2: ");
				number2 = scanner.nextInt();
				System.out.print("\nSum: "+(number1+number2));
				break;
			case 2:
				System.out.print("\nEnter number1: ");
				number1 = scanner.nextInt();
				System.out.print("\nEnter number2: ");
				number2 = scanner.nextInt();
				System.out.print("\nDifference: "+(number1-number2));
				break;
			case 3:
				System.out.print("\nEnter number1: ");
				number1 = scanner.nextInt();
				System.out.print("\nEnter number2: ");
				number2 = scanner.nextInt();
				System.out.print("\nProduct: "+(number1*number2));
				break;
			}
		} while (option!=4);

	}

}
