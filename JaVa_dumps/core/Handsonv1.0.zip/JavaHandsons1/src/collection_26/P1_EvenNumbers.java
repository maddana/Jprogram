package collection_26;

import java.util.ArrayList;

public class P1_EvenNumbers {
	ArrayList<Integer> arrayList = new ArrayList<Integer>();
	
	ArrayList<Integer> storeEvenNumber(int N){
		ArrayList<Integer> Al = new ArrayList<Integer>();
		for(int i=2;i<=N;i+=2)
			Al.add(i);
		arrayList.addAll(Al);
		return Al;
	}
	
	ArrayList<Integer> printEvenNumbers(){
		ArrayList<Integer> A2 = new ArrayList<Integer>();
		for(int i:arrayList)
			A2.add(i*2);
		return A2;
	}
	
	int retrieveEvenNumber(int N){
		int index=0;
		index = arrayList.indexOf(N);
		if(index<0)
			index=-0;
		return index;
	}
	
	public static void main(String arg[]){
		//ArrayList<Integer> al= new ArrayList<Integer>();
		P1_EvenNumbers po = new P1_EvenNumbers();
		System.out.print("\n"+po.storeEvenNumber(16));
		System.out.print("\n"+po.printEvenNumbers());
		System.out.print("\n"+po.retrieveEvenNumber(8));
		System.out.print("\n"+po.retrieveEvenNumber(21));
	}
}
