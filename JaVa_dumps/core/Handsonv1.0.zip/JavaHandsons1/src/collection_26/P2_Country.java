package collection_26;

import java.util.HashSet;

public class P2_Country {
	private HashSet<String> Country = new HashSet<String>();
	
	HashSet<String> storeCountryNames(String CountryName){
		HashSet<String> H1 = new HashSet<String>();
		H1.add(CountryName);
		Country.addAll(H1);
		return H1;
	}
	
	String retrieveCountry(String countryName){
		String country = "";
		for(String str:Country)
			if(str.equalsIgnoreCase(countryName))
				country = str;
		return country;
	}
	
	public static void main(String arg[]){
		P2_Country po = new P2_Country();
		po.storeCountryNames("India");
		po.storeCountryNames("Austrelia");
		po.storeCountryNames("Spain");
		
		System.out.print("\nCountry: "+po.retrieveCountry("india"));
		System.out.print("\nCountry: "+po.retrieveCountry("Germany"));
	}
}
