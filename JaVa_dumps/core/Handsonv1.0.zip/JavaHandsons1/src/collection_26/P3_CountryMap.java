package collection_26;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class P3_CountryMap {
	HashMap<String, String> hm = new HashMap<String, String>();
	
	
	@SuppressWarnings("unchecked")
	HashMap<String, String> storeCountryCapital(String country, String capital){
		HashMap<String, String> temp =new HashMap<String, String>();
		temp.put(country, capital);
		hm.putAll(temp);
		return (HashMap<String, String>)hm.clone();
	}
	
	String retrieveCapital(String country){
		String capital="";
		capital = hm.get(country);
		System.out.print("\nCountry: "+country+"\tCapital : "+capital);
		return capital;
	}
	
	String retrieveCountry(String capital){
		String country="";
		Set<String> countryList = hm.keySet();
		
		for(String str:countryList){
			if(hm.get(str).equalsIgnoreCase(capital))
				country = str;
		}
		System.out.print("\nCountry: "+country+"\tCapital : "+capital);
		return country;
	}
	
	ArrayList<String> getCountryList(){
		ArrayList<String> countryList = new ArrayList<String>();
		Iterator<String> itr = hm.keySet().iterator();
		while (itr.hasNext()) {
			String string = (String) itr.next();
			countryList.add(string);
		}
		
		return countryList;
	}
	
	Map<String, String> getInverseMap(Map<String, String> hm){
		Map<String, String> inverseMap = new HashMap<String, String>();
		Iterator<String> itr = hm.keySet().iterator();
		
		while (itr.hasNext()) {
			String string = (String) itr.next();
			inverseMap.put(hm.get(string), string);
		}
		
		return inverseMap;
	}
	
	public static void main(String arg[]){
		P3_CountryMap po = new P3_CountryMap();
		po.storeCountryCapital("India", "Delhi");
		po.storeCountryCapital("Japan", "Tokio");
		
		po.retrieveCapital("India");
		po.retrieveCountry("Tokio");
		System.out.print("\nInverseMap: "+po.getInverseMap(po.hm));
		System.out.print("\nCountryList: "+po.getCountryList());
	}
}
