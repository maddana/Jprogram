package Intro_Activity1;


class MyProgram {
	  public static void main(String arg[]){
	  System.out.println("My First Java Program");
	 }
	}
