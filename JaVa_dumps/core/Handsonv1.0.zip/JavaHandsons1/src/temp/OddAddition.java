package temp;

public class OddAddition {
	int n;
	int rem;
	int sum = 0;

	void SumOfOddDigits() {
		while (n != 0) {
			rem = n % 10;
			if (rem % 2 != 0) {
				sum = sum + rem;
			}
			n = n / 10;
		}
		System.out.println("Sum of digits :" + sum);
	}

	public static void main(String[] args) {
		OddAddition oddaddition = new OddAddition();
		oddaddition.n = 5432; // It was the last line, so n was 0 when you call
								// sumOfOddDigits
		oddaddition.SumOfOddDigits();

	}
}