package wrapper_19;

public class Student {
	void calculateFeeStructure(Long studentId,
			Character studentGrade,
			Double monthlyFee,
			Boolean isScholarShipEligible,
			Double fee){
		int percent=0;
		if(studentId!=0&&studentGrade.equals('A')&&
				isScholarShipEligible == true)
			{
			fee = monthlyFee*0.9;
			percent = 10;
			}
		else if(studentId!=0&&studentGrade.equals('B')&&
				isScholarShipEligible == true)
		{
			fee = monthlyFee*0.92;
			percent = 8;
			}
		else if(studentId!=0&&studentGrade.equals('C')&&
				isScholarShipEligible == true)
		{
			fee = monthlyFee*0.94;
			percent = 6;
			}
		else if(studentId!=0&&studentGrade.equals('D')&&
				isScholarShipEligible == true)
		{
			fee = monthlyFee*0.96;
			percent = 4;
			}
		else
			fee = 0.0;
		
		if(fee == 0)
			System.out.print("\nNot elegible for excemption");
		else
			System.out.print("\n"+percent+"% of fees is exempted, the calculated fees is "+ fee.intValue());
		//fee.intvalue is may not be round off function.
	}
	
	void compareMarks(Long Maths,Double English){
		Integer maths = Maths.intValue();
		Integer english = English.intValue();
		
		if(maths > english)
			System.out.print("\nMaths mark is higher than English");
		else if(maths<english)
			System.out.print("\nEnglish mark is higher than Maths");
		else
			System.out.print("\nBoth Are Equal");
	}
	
	void validateFees(Double fee){
		if(fee.isInfinite())
			System.out.print("\nFee is infinite");
		else
		{
			System.out.print("\nFee is not infinite:");
			System.out.print("\nByteValue of fee is: "+fee.byteValue());
		}
	}
	
	public static void main(String[] arg){
		Double fee=0.0;
		Student student= new Student();
		student.calculateFeeStructure(new Long(234), new Character('C'), new Double(600),new Boolean(true), fee);
		student.calculateFeeStructure(new Long(115), new Character('B'), new Double(909.50),new Boolean(true), fee);
		student.calculateFeeStructure(new Long(980), new Character('G'), new Double(1810),new Boolean(false), fee);
		
		System.out.print("\n");
		student.compareMarks(new Long(65), new Double(85));
		student.compareMarks(new Long(98), new Double(56));
		student.compareMarks(new Long(84), new Double(84));
		
		System.out.print("\n");
		student.validateFees(new Double(1500));
	}
}
