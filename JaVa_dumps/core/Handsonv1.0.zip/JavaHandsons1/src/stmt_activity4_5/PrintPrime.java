package stmt_activity4_5;

public class PrintPrime {
	void printPrime()
	{
		for(int i=0;i<150;i++)
			if(isPrime(i))
			System.out.print(" "+i);
	}
	
	boolean isPrime(int input){
		boolean prime = true;
		for(int i=2;i<input/2;i++){
			if(input%i == 0)
				prime = false;
		}
		return prime;
	}
	
	public static void main(String[] arg){
		PrintPrime ob = new PrintPrime();
		ob.printPrime();
	}
}
