package stmt_activity4_5;

public class PrintOdd {
	
	void printOdd(int last){
		int i;
		for(i=1;i<last;i+=2){
			System.out.print("\n");
			for(int j=1;j<=i;j+=2)
				System.out.print(" "+j);
		}
		i-=4;
		for(;i>0;i-=2){
			System.out.print("\n");
			for(int j=1;j<=i;j+=2)
				System.out.print(" "+j);
		}
	}
	
	public static void main(String arg[]){
		PrintOdd ob = new PrintOdd();
		ob.printOdd(20);
	}

}
